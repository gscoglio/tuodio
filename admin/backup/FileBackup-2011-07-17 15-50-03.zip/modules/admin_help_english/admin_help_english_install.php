<?php
	$module_info['name'] = 'Admin Help English';
	$module_info['desc'] = 'Help documents to introduce you to Pligg and provide you with common answers and definitions.';
	$module_info['version'] = 0.2;
	$module_info['requires'][] = array('multibox_admin', 0.1);
?>