<?php	
	$module_info['name'] = 'Friend Activity';
	$module_info['desc'] = 'Changes the vote box style when friend votes for a story';
	$module_info['version'] = 0.1;
?>