<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'EUJ7QvYuZgtHPilnUQ5dw');
define('CONSUMER_SECRET', 'EJZLWo3P6YCEEWHBL5TWLNLz0JQYixfORLG3qhDIs');
define('OAUTH_CALLBACK', 'http://www.tuodio.com.ar/modules/twitter-tool/twitter/callback.php');
