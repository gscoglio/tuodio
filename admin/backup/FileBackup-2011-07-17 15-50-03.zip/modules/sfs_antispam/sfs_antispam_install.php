<?php
	$module_info['name'] = 'SFS Antispam';
	$module_info['desc'] = 'Helps determine and block spam users. See readme file for configration instructions';
	$module_info['version'] = 0.7;
?>
