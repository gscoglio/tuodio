<?php

// Mi APP de Twitter
define('CONSUMER_KEY', 'EUJ7QvYuZgtHPilnUQ5dw');
define('CONSUMER_SECRET', 'EJZLWo3P6YCEEWHBL5TWLNLz0JQYixfORLG3qhDIs');

// OAuth ya validado ¡QUE NUNCA EXPIRA! 
define('OAUTH_TOKEN', '117065305-EYjuCJ4NNKzyjpBfWpslA9B4TxEGRMijNsdUPFBq');
define('OAUTH_TOKEN_SECRET','wNF1lnPm7r9v2Iwz4opSorWtj2SAauxpRmaGOWO5oHQ');

// Twitter Username
define('TWITTER_USERNAME', 'tuodio');

// Base de Datos
define('DB_BASE', 'twitter_script');
define('DB_USER', 'tuodio');
define('DB_PASS', 'verizon');
define('DB_HOST', '192.168.0.193');

// Donde esta el archivo de hashtags para este usuario
define('HASHTAGS_FILE','/www/minutodedescuento.com.ar/tuodio/modules/twitter-script/bots/tuodio/hashtags.txt');

// Donde estan los archivos de la libreria (debe terminar con /)
define('LIBRARY_PATH', '/www/minutodedescuento.com.ar/tuodio/modules/twitter-script/library/');

// Datos del mail
define('MAIL_TO', 'german.scoglio@gmail.com');
define('MAIL_SUBJECT', 'Cronjob TuOdio');
