<?php header('Content-Type: text/html; charset=utf-8');
	$module_info['name'] = 'Sidebar Statistics';
	$module_info['desc'] = 'Add statistics about your site to the sidebar.';
	$module_info['version'] = 0.1;
?>
