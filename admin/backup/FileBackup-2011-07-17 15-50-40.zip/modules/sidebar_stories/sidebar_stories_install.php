<?php
	$module_info['name'] = 'Sidebar Stories';
	$module_info['desc'] = 'Displays published and upcoming stories in the sidebar.';
	$module_info['version'] = 0.3;
	// $module_info['requires'][] = array('', 0.2);
?>
