<?php	
	$module_info['name'] = 'Anonymous Story';
	$module_info['desc'] = 'Allows user to submit anonymous story.';
	$module_info['version'] = 0.1;
	$module_info['requires'][] = array('anonymous', 0.1);
	
?>