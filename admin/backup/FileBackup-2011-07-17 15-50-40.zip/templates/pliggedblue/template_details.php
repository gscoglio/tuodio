<?php
        $template_info['name'] = 'pliggedblue'; // do not use the _ character. use - instead
        $template_info['desc'] = 'pliggedblue';
        $template_info['author'] = 'Social CMS Buzz';
        $template_info['support'] = 'http://socialcmsbuzz.com/';
        $template_info['version'] = 0.990;
        $template_info['designed_for_pligg_version'] = '9.9.0';
?>