<?php
	$template_info['name'] = 'The-Standard'; // do not use the _ character. use - instead
	$template_info['desc'] = 'The Standard is the first official template to support up and down voting for Pligg.';
	$template_info['author'] = 'Yankidank';
	$template_info['update_url'] = 'http://forums.pligg.com/versioncheck.php?product=thestandard';
	$template_info['support'] = 'http://forums.pligg.com/pligg-templates/18679-standard-template-yankidank.html';
	$template_info['version'] = 0.1;
	$template_info['designed_for_pligg_version'] = '1.0.0';
?>
