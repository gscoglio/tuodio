<?php
$my_base_url = 'http://www.tuodio.com.ar';
$my_pligg_base = '';
$dblang = 'en';
define('table_prefix', 'tuodio_');
$language = 'spanish';
include_once mnminclude.'settings_from_db.php';
?>