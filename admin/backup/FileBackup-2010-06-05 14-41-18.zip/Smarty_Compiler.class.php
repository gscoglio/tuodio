<?php

require_once(TEMPLATE_LITE_DIR . "class.compiler.php");

class Smarty_Compiler extends Smarty {

    function Smarty_Compiler()
    {
            }
}
?>