<?php
	$module_info['name'] = 'Simple Private Messaging';
	$module_info['desc'] = 'Let users send private messages to each other.';
	$module_info['version'] = 0.6;
?>
