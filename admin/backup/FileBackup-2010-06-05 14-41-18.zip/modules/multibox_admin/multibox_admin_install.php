<?php
	$module_info['name'] = 'Multibox Admin';
	$module_info['desc'] = 'Inserts the required Javascript and CSS for the Mootools Multibox effect to be used in the admin panel.';
	$module_info['version'] = 0.1;
?>