<?php
	$module_info['name'] = 'Links';
	$module_info['desc'] = 'Replaces links in comments and stories';
	$module_info['version'] = 0.1;
	$module_info['settings_url'] = '../module.php?module=links';
?>
