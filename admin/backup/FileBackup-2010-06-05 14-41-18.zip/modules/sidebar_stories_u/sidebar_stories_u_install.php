<?php
	$module_info['name'] = 'Sidebar Top Today';
	$module_info['desc'] = 'Displays the top stories today.';
	$module_info['version'] = 0.3;
	// $module_info['requires'][] = array('', 0.2);
?>
